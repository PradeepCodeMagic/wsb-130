import React from 'react'
import Header from './comman/Header'

export default function AddCart() {
  return (
    <div>
   
      cart page
    </div>
  )
}
